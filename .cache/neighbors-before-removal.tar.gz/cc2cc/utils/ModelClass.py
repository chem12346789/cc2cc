import faulthandler
import os
import random
import shutil
import time
from collections import deque
from contextlib import contextmanager
from io import BytesIO
from typing import cast

import numpy as np
import pandas as pd
import torch
import torch.distributed as dist
import torch.optim as optim
from torch.nn.parallel import DistributedDataParallel

from cc2cc.utils.DataBase import DataBase
from cc2cc.utils.env_var import CHECKPOINTS_PATH, CUBE_MIDDLE, MAIN_PATH
from cc2cc.utils.mol import AU2KCALMOL
from cc2cc.utils.schedulers import CosineAnnealingWarmRestarts2
from cc2cc.utils.grid_neighbors import RadiusNeighborhoods
from cc2cc.utils.zmp_ov_training import GaussianOrbitalCache

CUBE_INDEX = {
    "cube5": np.array(
        [(0, 0, 0), (0, 2, 2), (1, 1, 1), (2, 2, 0), (2, 0, 2)],
        dtype=np.int64,
    ),
    "cube9": np.array(
        [
            (0, 0, 0),
            (0, 0, 2),
            (0, 2, 0),
            (0, 2, 2),
            (1, 1, 1),
            (2, 0, 0),
            (2, 0, 2),
            (2, 2, 0),
            (2, 2, 2),
        ],
        dtype=np.int64,
    ),
}
B3LYP_WEIGHTS = (0.08, 0.19, 0.72, 0.81)
TORCH_LIST = [
    "loss_ene",
    "loss_ene_abs",
    "loss_ene_atomic",
    "loss_grad_record",
    "loss_tot",
    "loss_tot_ene",
    "loss_tot_abs",
    "loss_tot_grad",
    "loss_tot_atomic",
    "loss_zmp_ov",
]
TIME_LIST = [
    "time_loss_tot_ene",
    "time_loss_tot_abs",
    "time_loss_tot_grad",
    "time_loss_tot_atomic",
]

STATE_DICT_PREFIXES = ("_orig_mod.",)
DEBUG = 0


@contextmanager
def _training_stage(stage, batch=None):
    setting = os.environ.get("DFT2CC_TRACE_TRAIN", "0")
    if setting not in ("0", "1"):
        raise ValueError("DFT2CC_TRACE_TRAIN must be 0 or 1")
    if setting == "0":
        yield
        return

    label = f"[train-progress] pid={os.getpid()} stage={stage}"
    device = None
    if batch is not None:
        device = batch["input"].device
        label += f" name={batch.get('name', 'atomic')} device={device} grids={len(batch['input'])}"
        neighbors = batch.get("neighbor_indices")
        if isinstance(neighbors, RadiusNeighborhoods):
            label += f" edges={int(neighbors.counts.sum())}"
    print(f"{label} start", flush=True)
    start = time.perf_counter()
    faulthandler.dump_traceback_later(120, repeat=True)
    try:
        yield
        if device is not None and device.type == "cuda":
            torch.cuda.synchronize(device)
    finally:
        faulthandler.cancel_dump_traceback_later()
    print(f"{label} done wall_s={time.perf_counter() - start:.3f}", flush=True)


class _CheckpointSizeBuffer(BytesIO):
    def __init__(self):
        super().__init__()
        self.size = 0

    def write(self, data):
        # Discard streamed tensor bytes instead of buffering the whole checkpoint.
        size = len(data)
        self.size += size
        return size


class _LossEvent:
    def __init__(self, event, data_record, timing_events):
        self.event = event
        self.data_record = data_record
        self.timing_events = timing_events

    def _resolve_timings(self):
        for key, (start, end) in self.timing_events.items():
            self.data_record[key] = np.array(start.elapsed_time(end) / 1000.0)
        self.timing_events.clear()

    def query(self):
        is_complete = self.event.query()
        if is_complete:
            self._resolve_timings()
        return is_complete

    def synchronize(self):
        self.event.synchronize()
        self._resolve_timings()


class DataRecordList:
    def __init__(self, len_batch):
        self.data_dict = {
            "name": ["" for _ in range(len_batch)],
        }
        for key in TORCH_LIST + TIME_LIST:
            self.data_dict[key] = np.zeros(len_batch)
        self.iter = 0

    def add_data_record(self, data_record):
        for key, values in self.data_dict.items():
            if key not in data_record:
                raise ValueError(f"Key {key} not found in data_record.")
            value = data_record[key]
            if key == "name":
                values[self.iter] = value
            elif key in TIME_LIST:
                values[self.iter] = value.item()
            else:
                values[self.iter] = AU2KCALMOL * value.item()
        self.iter += 1

    def save(self, path):
        pd.DataFrame(self.data_dict).to_csv(path, index=False)

    def trim(self):
        self.data_dict = {
            key: values[: self.iter] for key, values in self.data_dict.items()
        }

    def merge(self):
        self.data_dict = (
            pd.DataFrame(self.data_dict)
            .groupby("name")
            .mean()
            .reset_index()
            .to_dict(orient="list")
        )
        self.iter = len(self.data_dict["name"])


class ModelClass:
    def __init__(self, args):
        self.args = args
        self.start_step = 0
        self.dir_checkpoint = None
        self.state_dict = None
        self.optimizer_state_dict = None
        self.rng_state_dict = None
        self.rng_state_for_save = None
        self.zmp_ov_cache = None

        # for distributed training
        self.verbose = True
        if args.device == "cuda":
            if self.args.distributed:
                self.local_rank = int(os.environ["LOCAL_RANK"])
                torch.cuda.set_device(self.local_rank)
                dist.init_process_group(
                    backend="nccl",
                    rank=self.local_rank,
                    world_size=torch.cuda.device_count(),
                    device_id=torch.device("cuda", self.local_rank),
                )
                self.verbose = dist.get_rank() == 0
            else:
                self.local_rank = 0
        else:
            self.local_rank = "cpu"

    def init_model(self, init_train=False):
        self.load_model()

        if not (MAIN_PATH / f"cc2cc/utils/model/{self.args.model}.py").exists():
            raise ValueError("Unknown model")
        model = getattr(
            __import__(f"cc2cc.utils.model.{self.args.model}", fromlist=["Model"]),
            "Model",
        )

        self.model: torch.nn.Module = model().to(self.args.device)
        if self.args.precision == "float64":
            self.model.double()

        param = next(self.model.parameters())
        self.device, self.dtype = param.device, param.dtype
        self.cube_type = self.model.cube_type
        self.cube_size = self.model.cube_size
        self.radius_cutoff = getattr(self.model, "radius_cutoff", None)
        self.input_level = self.model.input_level
        if self.cube_type == "neighbors" and self.args.if_grad:
            if self.dtype != torch.float64:
                raise ValueError("No-cube force training requires --precision float64.")
            self.print(
                "No-cube force training uses cached fixed-grid feature derivatives, "
                "not a complete analytic total nuclear gradient."
            )
        for name in ("cube_type", "cube_size", "input_level"):
            self.print(f"{name}: {getattr(self, name)}")
        if self.radius_cutoff is not None:
            self.print(
                f"radius_cutoff: {self.radius_cutoff} Bohr "
                "(all points; cube_size is the latent width)"
            )

        if self.state_dict is not None:
            self.model.load_state_dict(self.state_dict, strict=True)
            self.state_dict = None

        self._maybe_compile_model()

        if init_train:
            if self.args.if_resume:
                self.print("Resuming training from checkpoint.")
                # Checkpoints contain the updates from the named epoch.
                self.start_step = int(self.args.load_epoch) + 1

            self.dir_checkpoint = (
                CHECKPOINTS_PATH / f"checkpoint_{self.args.save_dir}"
            ).resolve()
            self.print(f"Checkpoint directory: {self.dir_checkpoint}")

            if self.args.distributed:
                self.print(f"Using DistributedDataParallel on rank {self.local_rank}")
                self.model = DistributedDataParallel(
                    self.model, device_ids=[self.local_rank]
                )

            self.init_train()

    def _maybe_compile_model(self):
        if self.args.if_grad or getattr(self.args, "zmp_ov_loss", False):
            return

        if self.radius_cutoff is not None:
            self.print(
                "Running radius model in eager mode: variable-length neighborhood "
                "loops are not compiled."
            )
            return

        try:
            compiled_model = torch.compile(self.model)
            self.model = cast(torch.nn.Module, compiled_model)
            self.print("torch.compile enabled; compilation occurs on first use.")
        except Exception as exc:  # pragma: no cover - fallback path
            self.print(f"torch.compile failed ({exc}). Using eager mode.")

    def _normalize_state_dict(self, state_dict: dict[str, torch.Tensor]):
        normalized_state_dict = {}
        for key, value in state_dict.items():
            normalized_key = key
            prefix_removed = True
            while prefix_removed:
                prefix_removed = False
                for prefix in STATE_DICT_PREFIXES:
                    if normalized_key.startswith(prefix):
                        normalized_key = normalized_key[len(prefix) :]
                        prefix_removed = True
            normalized_state_dict[normalized_key] = value
        return normalized_state_dict

    def _state_dict_for_save(self):
        return self._normalize_state_dict(self.model.state_dict())

    def print(self, msg):
        if self.verbose:
            print(msg, flush=True)

    def load_model(self):
        if not self.args.load:
            if getattr(self.args, "if_resume", False):
                raise ValueError("Resuming training requires --load and --load_epoch.")
            self.print("No checkpoint specified, starting from scratch.")
            return
        load_checkpoint = (CHECKPOINTS_PATH / f"checkpoint_{self.args.load}").resolve()
        load_path = load_checkpoint / f"{self.args.load_epoch}.pth"
        self.print(f"Checking path {load_path}")
        if load_path.exists():
            self.print("Loading model from path")
            checkpoint = torch.load(
                load_path, map_location=self.args.device, weights_only=True
            )
            state_dict = self._normalize_state_dict(checkpoint["state_dict"])
            self.state_dict = state_dict
            self.args.model = checkpoint["model"]
            if getattr(self.args, "if_resume", False):
                self.optimizer_state_dict = checkpoint.get("optimizer")
                if self.optimizer_state_dict is None:
                    raise ValueError(
                        f"Resume checkpoint has no optimizer state: {load_path}"
                    )
                self.rng_state_dict = checkpoint.get("rng_state")
            self.print(f"Model loaded from {load_path} with model {self.args.model}")
        else:
            if getattr(self.args, "if_resume", False):
                raise FileNotFoundError(f"Resume checkpoint not found: {load_path}")
            self.print("Model not found, starting from scratch.")

    def init_train(self):
        if self.args.optimizer == "Muon":
            from pytorch_optimizer import Muon

            muon_params = []
            adamw_params = []
            for name, param in self.model.named_parameters():
                if param.ndim >= 2 and "mixing_weight" not in name.split("."):
                    muon_params.append(param)
                else:
                    adamw_params.append(param)

            # Muon orthogonalizes updates in bfloat16; model weights remain float64.
            self.optimizer = Muon(
                [
                    dict(params=adamw_params, lr=self.args.lr, use_muon=False),
                    dict(params=muon_params, lr=self.args.muon_lr, use_muon=True),
                ],
                weight_decay=self.args.weight_decay,
                adamw_wd=self.args.weight_decay,
                adamw_betas=(0.9, 0.999),
                adamw_eps=1e-8,
            )
        else:
            optimizer_cls = {
                "AdamW": optim.AdamW,
                "Adafactor": getattr(optim, "Adafactor", None),
            }.get(self.args.optimizer)
            if optimizer_cls is None:
                raise ValueError(f"Unknown optimizer {self.args.optimizer}")
            self.optimizer = optimizer_cls(
                self.model.parameters(),
                lr=self.args.lr,
                weight_decay=self.args.weight_decay,
            )
        if self.optimizer_state_dict is not None:
            self.optimizer.load_state_dict(self.optimizer_state_dict)
            self.optimizer_state_dict = None

        self.scheduler = None

        loss_dict = {
            "L1Loss": torch.nn.L1Loss,
            "MSELoss": torch.nn.MSELoss,
        }
        loss_class = loss_dict[self.args.loss_type]
        self.loss_fun = loss_class(reduction="sum").cuda(self.local_rank)

    def init_database(self, train_str_dict, eval_str_dict):
        def process_input(x):
            if self.cube_type == "center_4":
                return x[:, : self.input_level, CUBE_MIDDLE, CUBE_MIDDLE, CUBE_MIDDLE]
            if self.cube_type == "cube":
                return x[:, : self.input_level, :, :, :].reshape(
                    x.shape[0], self.input_level, self.cube_size
                )
            if self.cube_type in CUBE_INDEX:
                idx = CUBE_INDEX[self.cube_type]
                return x[
                    :,
                    : self.input_level,
                    idx[:, 0],
                    idx[:, 1],
                    idx[:, 2],
                ]
            raise ValueError(f"Unknown cube type: {self.cube_type}")

        def process_grad2force(x):
            if self.cube_type == "neighbors":
                if x.ndim != 4 or x.shape[-1] != 3:
                    raise ValueError(
                        "Expected compact no-cube Jacobian (atoms, channels, grids, 3); "
                        "regenerate expanded archives."
                    )
                return (
                    x[:, : self.input_level]
                    .transpose(2, 1, 0, 3)
                    .reshape(x.shape[2], self.input_level, -1)
                )
            # tipabcx -> tipCx -> piCtx
            if self.cube_type == "center_4":
                x = x[
                    :, : self.input_level, :, [CUBE_MIDDLE], CUBE_MIDDLE, CUBE_MIDDLE, :
                ]
            elif self.cube_type == "cube":
                x = x[:, : self.input_level, :, :, :, :, :].reshape(
                    x.shape[0],
                    self.input_level,
                    x.shape[2],
                    self.cube_size,
                    x.shape[-1],
                )
            elif self.cube_type in CUBE_INDEX:
                idx = CUBE_INDEX[self.cube_type]
                x = x[
                    :,
                    : self.input_level,
                    :,
                    idx[:, 0],
                    idx[:, 1],
                    idx[:, 2],
                    :,
                ]
            else:
                raise ValueError(f"Unknown cube type: {self.cube_type}")
            # tipCx -> piCtx
            x = np.transpose(x, (2, 1, 3, 0, 4))
            shape_x = x.shape
            return x.reshape(shape_x[0], shape_x[1], shape_x[2], -1)

        self.database_train = DataBase(
            train_str_dict,
            self.args,
            process_input=process_input,
            process_grad2force=process_grad2force,
            verbose=self.verbose,
            input_mode=self.cube_type,
            neighborhood_size=self.cube_size,
            radius_cutoff=self.radius_cutoff,
        )
        self.database_eval = DataBase(
            eval_str_dict,
            self.args,
            shuffle=False,
            if_eval=True,
            atomic_name_dict=self.database_train.atomic_name_dict,
            atomic_energy_dict=self.database_train.atomic_energy_dict,
            process_input=process_input,
            process_grad2force=process_grad2force,
            verbose=self.verbose,
            input_mode=self.cube_type,
            neighborhood_size=self.cube_size,
            radius_cutoff=self.radius_cutoff,
        )

        if getattr(self.args, "zmp_ov_loss", False):
            self._init_zmp_ov_cache()

        self.print(f"Training on {len(self.database_train)} systems.")
        self.print(f"Evaluating on {len(self.database_eval)} systems.")

        steps_per_epoch = len(self.database_train.data_gpu)
        start_update = self.start_step * steps_per_epoch
        max_lrs = [
            self.args.muon_lr if group.get("use_muon", False) else self.args.lr
            for group in self.optimizer.param_groups
        ]
        for group, max_lr in zip(self.optimizer.param_groups, max_lrs):
            group["initial_lr"] = max_lr
            group["lr"] = max_lr

        if self.args.scheduler == "onecycle":
            for group, max_lr in zip(self.optimizer.param_groups, max_lrs):
                group["initial_lr"] = max_lr / 25.0
                group["max_lr"] = max_lr
                group["min_lr"] = max_lr / 25.0 / 1000.0
            self.scheduler = optim.lr_scheduler.OneCycleLR(
                self.optimizer,
                max_lr=max_lrs,
                total_steps=(self.args.epoch + 1) * steps_per_epoch,
                pct_start=0.1,
                anneal_strategy="cos",
                cycle_momentum=False,
                div_factor=25.0,
                final_div_factor=1000.0,
                last_epoch=start_update - 1,
            )
        elif self.args.scheduler == "cosine":
            self.scheduler = optim.lr_scheduler.CosineAnnealingLR(
                self.optimizer,
                T_max=self.args.cosine_T * steps_per_epoch,
                eta_min=self.args.cosine_eta_min,
                last_epoch=start_update - 1,
            )
        elif self.args.scheduler == "constant":
            total_iters = 5 * steps_per_epoch
            if 0 < start_update <= total_iters:
                for group in self.optimizer.param_groups:
                    group["lr"] /= 3.0
            self.scheduler = optim.lr_scheduler.ConstantLR(
                self.optimizer,
                total_iters=total_iters,
                last_epoch=start_update - 1,
            )
        elif self.args.scheduler == "cosine_warm2":
            if (
                self.args.cosine_restart_lr is None
                or self.args.cosine_restart_step is None
            ):
                raise ValueError(
                    "cosine_warm2 requires --cosine_restart_lr and --cosine_restart_step"
                )
            self.scheduler = CosineAnnealingWarmRestarts2(
                self.optimizer,
                T_0=self.args.cosine_T * steps_per_epoch,
                T_mult=self.args.cosine_T_mult,
                eta_min=self.args.cosine_eta_min,
                restart_step=self.args.cosine_restart_step * steps_per_epoch,
                restart_lrs=[
                    self.args.cosine_restart_lr * max_lr / self.args.lr
                    for max_lr in max_lrs
                ],
            )
            if start_update:
                self.scheduler.step(start_update)
        elif self.args.scheduler == "cosine_warm":
            self.scheduler = optim.lr_scheduler.CosineAnnealingWarmRestarts(
                self.optimizer,
                T_0=self.args.cosine_T * steps_per_epoch,
                T_mult=self.args.cosine_T_mult,
                eta_min=self.args.cosine_eta_min,
            )
            if start_update:
                self.scheduler.step(start_update)
        else:
            raise ValueError(f"Unknown scheduler {self.args.scheduler}")

    @staticmethod
    def capture_rng_state():
        python_state = random.getstate()
        numpy_state = np.random.get_state()
        state = {
            "python": torch.tensor(
                (python_state[0], *python_state[1]),
                dtype=torch.int64,
                device="cpu",
            ),
            "python_gauss": torch.tensor(
                (python_state[2] is not None, python_state[2] or 0.0),
                dtype=torch.float64,
                device="cpu",
            ),
            "numpy_name": torch.tensor(
                list(numpy_state[0].encode("ascii")),
                dtype=torch.uint8,
                device="cpu",
            ),
            "numpy_keys": torch.tensor(
                numpy_state[1].tolist(),
                dtype=torch.int64,
                device="cpu",
            ),
            "numpy_meta": torch.tensor(
                (numpy_state[2], numpy_state[3]),
                dtype=torch.int64,
                device="cpu",
            ),
            "numpy_gauss": torch.tensor(
                (numpy_state[4],),
                dtype=torch.float64,
                device="cpu",
            ),
            "torch": torch.get_rng_state(),
        }
        if torch.cuda.is_initialized():
            state["cuda"] = torch.cuda.get_rng_state().cpu()
        return state

    def restore_rng_state(self):
        if self.rng_state_dict is None:
            return

        state = self.rng_state_dict
        if isinstance(state, list):
            if dist.is_initialized() and len(state) != dist.get_world_size():
                raise ValueError(
                    "Checkpoint RNG state rank count differs from the current process group."
                )
            rank = dist.get_rank() if dist.is_initialized() else 0
            if rank >= len(state):
                raise ValueError(
                    "Checkpoint RNG state has fewer ranks than the current process group."
                )
            state = state[rank]
        python_state = state["python"].cpu().tolist()
        python_gauss = state["python_gauss"].cpu().tolist()
        random.setstate(
            (
                python_state[0],
                tuple(python_state[1:]),
                python_gauss[1] if python_gauss[0] else None,
            )
        )
        numpy_name = bytes(state["numpy_name"].cpu().tolist()).decode("ascii")
        numpy_meta = state["numpy_meta"].cpu().tolist()
        np.random.set_state(
            (
                numpy_name,
                np.asarray(state["numpy_keys"].cpu().numpy(), dtype=np.uint32),
                numpy_meta[0],
                numpy_meta[1],
                state["numpy_gauss"].cpu().item(),
            )
        )
        torch.set_rng_state(state["torch"].cpu())
        if "cuda" in state and torch.cuda.is_available():
            torch.cuda.set_rng_state(state["cuda"].cpu())

    def _estimate_checkpoint_size(self, state_dict, rng_state=None):
        payload = {
            "state_dict": state_dict,
            "model": self.args.model,
            "optimizer": self.optimizer.state_dict(),
            "rng_state": (
                rng_state or self.rng_state_for_save or self.capture_rng_state()
            ),
        }
        with _CheckpointSizeBuffer() as buffer:
            torch.save(payload, buffer)
            return max(buffer.size, 1 << 20)

    def save_model(self, epoch):
        if not self.dir_checkpoint.exists():
            self.print(f"Directory {self.dir_checkpoint} not found. Created!")
            (self.dir_checkpoint / "loss").mkdir(parents=True, exist_ok=True)

        state_dict = self._state_dict_for_save()
        checkpoint_path = self.dir_checkpoint / f"{epoch}.pth"
        rng_state = self.rng_state_for_save or self.capture_rng_state()
        payload = {
            "state_dict": state_dict,
            "model": self.args.model,
            "optimizer": self.optimizer.state_dict(),
            "rng_state": rng_state,
        }
        required_bytes = self._estimate_checkpoint_size(state_dict, rng_state)

        while True:
            free_bytes = shutil.disk_usage(self.dir_checkpoint).free
            if free_bytes >= required_bytes:
                try:
                    torch.save(payload, checkpoint_path)
                    return
                except OSError as exc:
                    msg = str(exc).lower()
                    if "no space left" in msg or "file write failed" in msg:
                        self.print(
                            "Disk space became insufficient while writing checkpoint; "
                            f"waiting for free disk before retrying {checkpoint_path}."
                        )
                        time.sleep(30)
                        continue
                    raise

            self.print(
                "Waiting for free disk space before saving checkpoint: "
                f"{free_bytes} bytes free, {required_bytes} bytes required."
            )
            time.sleep(30 * 60)  # Wait for 30 minutes before checking again

    def train(self):
        self.model.train(True)

    def eval(self):
        self.model.eval()

    def model_output(
        self, input_, weight, relative_positions=None, *, neighbor_indices=None
    ):
        model = (
            self.model.module
            if isinstance(self.model, DistributedDataParallel)
            else self.model
        )
        center_input = input_
        if isinstance(neighbor_indices, RadiusNeighborhoods):
            if relative_positions is None:
                raise ValueError("Radius neighborhoods require grid coordinates.")
            return input_, self.model(
                input_, relative_positions, neighborhoods=neighbor_indices
            ) * weight
        if model.cube_type == "neighbors":
            if neighbor_indices is not None:
                input_ = input_[neighbor_indices].permute(0, 2, 1).contiguous()
            if model.before_weight:
                input_ = torch.einsum("p...,pi->p...", input_, weight)
            if relative_positions is None:
                raise ValueError("Neighbor model requires relative_positions.")
            output = self.model(input_, relative_positions)
            derivative_input = center_input if neighbor_indices is not None else input_
        else:
            if model.before_weight:
                input_ = torch.einsum("p...,pi->p...", input_, weight)
            output = self.model(input_)
            derivative_input = input_
        return derivative_input, output if model.before_weight else output * weight

    def _init_zmp_ov_cache(self):
        if self.args.rho_input != "zmp":
            raise ValueError("--zmp_ov_loss requires --rho_input zmp.")
        if self.dtype != torch.float64:
            raise ValueError("--zmp_ov_loss requires --precision float64.")
        if self.args.distributed:
            raise ValueError("--zmp_ov_loss currently requires non-distributed training.")
        if self.cube_type != "cube" or self.cube_size != 27:
            raise ValueError("--zmp_ov_loss currently requires 3x3x3 cube inputs.")
        if getattr(self.model, "before_weight", False):
            raise ValueError("--zmp_ov_loss does not support models with before_weight.")
        if not 1 <= self.input_level <= 7:
            raise ValueError("--zmp_ov_loss supports one to seven input features.")
        if self.args.zmp_ov_block_size <= 0:
            raise ValueError("--zmp_ov_block_size must be positive.")
        if self.args.zmp_ov_loss_multiplier <= 0:
            raise ValueError("--zmp_ov_loss_multiplier must be positive.")

        modules = tuple(self.model.modules())
        dropout_types = (
            torch.nn.Dropout,
            torch.nn.Dropout1d,
            torch.nn.Dropout2d,
            torch.nn.Dropout3d,
            torch.nn.AlphaDropout,
            torch.nn.FeatureAlphaDropout,
        )
        batch_norm_types = (
            torch.nn.BatchNorm1d,
            torch.nn.BatchNorm2d,
            torch.nn.BatchNorm3d,
            torch.nn.SyncBatchNorm,
        )
        if any(isinstance(module, dropout_types) and module.p > 0 for module in modules):
            raise ValueError(
                "Two-pass ZMP training requires deterministic model evaluations; "
                "nonzero dropout is unsupported."
            )
        if any(isinstance(module, batch_norm_types) for module in modules):
            raise ValueError(
                "Two-pass ZMP training requires model outputs independent "
                "across grid centers; batch normalization is unsupported."
            )

        names = set(self.database_train.dataset.name_list)
        if len(names) != 1:
            raise ValueError(
                "--zmp_ov_loss currently requires exactly one training system "
                "so its complete constraint cache can remain GPU-resident."
            )
        name = next(iter(names))
        batch = self.database_train.dataset.data[name]
        self.zmp_ov_cache = GaussianOrbitalCache.from_archive(
            name,
            batch["input"],
            batch["weight"],
            self.device,
            self.args.zmp_ov_block_size,
        )
        batch["input"] = self.zmp_ov_cache.input.detach()
        batch["weight"] = self.zmp_ov_cache.weights
        self.print(
            f"Loaded all-grid Gaussian ZMP factors for {name} on {self.device}; "
            f"input shape={tuple(self.zmp_ov_cache.input.shape)}."
        )

    def _zmp_ov_loss(self, accumulate_parameter_gradients):
        cache = self.zmp_ov_cache
        if cache is None:
            raise RuntimeError("The ZMP orbital cache is not initialized.")

        fock = cache.fock0.clone()
        for start, stop in cache.batches():
            input_tile = cache.input[start:stop].detach().requires_grad_(True)
            _, output = self.model_output(
                input_tile, cache.weights[start:stop]
            )
            feature_gradient = torch.autograd.grad(
                output.sum(), input_tile, create_graph=False
            )[0]
            fock = fock + cache.fock_tile(feature_gradient, start)

        residual = cache.cv.T @ fock @ cache.co
        loss = (
            self.args.zmp_ov_loss_multiplier
            * torch.mean(residual * residual)
        )
        if accumulate_parameter_gradients:
            fock_adjoint = cache.cv @ (
                2
                * self.args.zmp_ov_loss_multiplier
                * residual
                / residual.numel()
            ) @ cache.co.T
            parameters = tuple(
                parameter
                for parameter in self.model.parameters()
                if parameter.requires_grad
            )
            for start, stop in cache.batches():
                input_tile = cache.input[start:stop].detach().requires_grad_(True)
                _, output = self.model_output(
                    input_tile, cache.weights[start:stop]
                )
                feature_gradient = torch.autograd.grad(
                    output.sum(), input_tile, create_graph=True
                )[0]
                fock_tile = cache.fock_tile(feature_gradient, start)
                surrogate = torch.sum(fock_adjoint * fock_tile)
                gradients = torch.autograd.grad(
                    surrogate, parameters, allow_unused=True
                )
                for parameter, gradient in zip(parameters, gradients):
                    if gradient is None:
                        continue
                    if parameter.grad is None:
                        parameter.grad = gradient.detach()
                    else:
                        parameter.grad.add_(gradient.detach())
        return loss.detach()

    def _zmp_ov_loss_for_eval(self):
        with torch.inference_mode(False), torch.enable_grad():
            return self._zmp_ov_loss(accumulate_parameter_gradients=False)

    def loss(self, batch, if_train=True, if_grad=True):
        input_ = batch["input"]
        weight = batch["weight"]
        if_use_cuda_event = input_.is_cuda
        tensor_to_numpy = lambda x: (
            x.detach().to("cpu", non_blocking=if_use_cuda_event)
            if x.is_cuda
            else x.detach().numpy()
        )
        sum_target = batch["energy_target"]
        scale = batch["scale"]
        scale_abs = batch["scale_abs"]
        scale_grad = batch["scale_grad"]
        scale_atomic = batch["scale_atomic"]
        data_record = {"name": batch["name"]}
        timing_events = {}

        def start_timing():
            if if_use_cuda_event:
                event = torch.cuda.Event(enable_timing=True)
                event.record()
                return event
            return time.perf_counter()

        def finish_timing(key, start):
            if if_use_cuda_event:
                end = torch.cuda.Event(enable_timing=True)
                end.record()
                timing_events[key] = (start, end)
            else:
                data_record[key] = np.array(time.perf_counter() - start)

        if DEBUG:
            print(f"{batch['name']}")

        if if_train:
            input_.requires_grad_(
                self.args.if_grad and if_grad and batch["grad_cc_train"].ndim != 0
            )
        else:
            input_ = input_.detach()

        relative_positions = batch.get("relative_positions")
        with _training_stage("forward" if if_train else "eval-forward", batch):
            input_, output = self.model_output(
                input_,
                weight,
                relative_positions,
                neighbor_indices=batch.get("neighbor_indices"),
            )
        if not if_train:
            output = output.detach()

        sum_output = torch.sum(output)
        if if_train:
            timing_start = start_timing()
            tot_loss = scale * self.loss_fun(sum_target, sum_output)
            data_record["loss_tot_ene"] = tensor_to_numpy(tot_loss)
            finish_timing("time_loss_tot_ene", timing_start)
        else:
            tot_loss = torch.tensor(0.0, device=self.device, dtype=self.dtype)
        data_record["loss_ene"] = tensor_to_numpy(torch.abs(sum_target - sum_output))

        if if_train:
            if self.args.if_abs:
                timing_start = start_timing()
                target = batch["output"] * weight
                abs_error = torch.abs(target - output)
                loss_ene_abs = scale_abs * self.loss_fun(target, output)
                tot_loss = tot_loss + loss_ene_abs
                data_record["loss_ene_abs"] = tensor_to_numpy(torch.sum(abs_error))
                data_record["loss_tot_abs"] = tensor_to_numpy(loss_ene_abs)
                finish_timing("time_loss_tot_abs", timing_start)

            if self.args.if_grad and if_grad:
                grad_cc_train = batch["grad_cc_train"]
                grad2force = batch["grad2force"]
                if len(grad_cc_train.shape) != 0:
                    timing_start = start_timing()
                    middle_ = torch.autograd.grad(
                        outputs=torch.sum(output),
                        inputs=input_,
                        create_graph=True,
                    )[0]
                    model = (
                        self.model.module
                        if isinstance(self.model, DistributedDataParallel)
                        else self.model
                    )
                    if model.cube_type == "neighbors":
                        force = torch.einsum("pi,pix->x", middle_, grad2force)
                    else:
                        force = torch.einsum("piC,piCx->x", middle_, grad2force)

                    loss_grad = scale_grad * self.loss_fun(grad_cc_train, force)
                    tot_loss = tot_loss + loss_grad
                    data_record["loss_grad_record"] = tensor_to_numpy(
                        torch.sum(torch.abs(grad_cc_train - force))
                    )
                    data_record["loss_tot_grad"] = tensor_to_numpy(loss_grad)
                    finish_timing("time_loss_tot_grad", timing_start)

        if self.args.if_atomic and scale_atomic != 0:
            if if_train:
                timing_start = start_timing()
            ae_target = batch["ae_target"]
            ae_output = sum_output.clone()

            if_finish = True
            for i_system, system_atom in enumerate(batch["atomic_systems"]):
                name_atom = self.database_train.atomic_name_dict.get(system_atom)
                if DEBUG:
                    print(
                        f"atom {system_atom} and stoichiometry {batch['atomic_stoichiometry'][i_system]}"
                    )
                if name_atom is None:
                    self.print(
                        f"Warning: {system_atom} not found in atomic_name_dict, "
                        "skipping atomic energy calculation."
                    )
                    if_finish = False
                    break
                atomic_batch = self.database_train.dataset.get_from_name(name_atom)
                atomic_batch = self.database_train.process_batch(
                    {
                        key: atomic_batch[key]
                        for key in (
                            "input",
                            "weight",
                            "neighbor_indices",
                            "relative_positions",
                        )
                        if key in atomic_batch
                    },
                    device=self.local_rank,
                )
                with _training_stage(f"atomic-forward:{name_atom}", atomic_batch):
                    _, atomic_output = self.model_output(
                        atomic_batch["input"],
                        atomic_batch["weight"],
                        atomic_batch.get("relative_positions"),
                        neighbor_indices=atomic_batch.get("neighbor_indices"),
                    )
                atomic_output = torch.sum(atomic_output)
                ae_output -= batch["atomic_stoichiometry"][i_system] * atomic_output

            if if_finish:
                if if_train:
                    loss_atomic = scale_atomic * self.loss_fun(ae_target, ae_output)
                    tot_loss = tot_loss + loss_atomic
                    data_record["loss_tot_atomic"] = tensor_to_numpy(loss_atomic)
                data_record["loss_ene_atomic"] = tensor_to_numpy(
                    torch.abs(ae_target - ae_output)
                )
            else:
                data_record["loss_tot_atomic"] = np.array(0.0)
                data_record["loss_ene_atomic"] = np.array(0.0)
            if if_train:
                finish_timing("time_loss_tot_atomic", timing_start)

        data_record["loss_tot"] = tensor_to_numpy(tot_loss)
        for key in TORCH_LIST:
            if key not in data_record:
                data_record[key] = np.array(0.0)
        for key in TIME_LIST:
            if key not in data_record and key not in timing_events:
                data_record[key] = np.array(0.0)

        event = None
        if if_use_cuda_event:
            final_event = torch.cuda.Event()
            final_event.record()
            event = _LossEvent(final_event, data_record, timing_events)

        if DEBUG:
            print(data_record)
            print("end of loss\n")
        return tot_loss, data_record, event

    def train_model(self, if_grad=True):
        memory_setting = os.environ.get("DFT2CC_PROFILE_TRAIN_MEMORY", "0")
        if memory_setting not in ("0", "1"):
            raise ValueError("DFT2CC_PROFILE_TRAIN_MEMORY must be 0 or 1")
        profile_memory = memory_setting == "1"
        if profile_memory:
            memory_device = next(self.model.parameters()).device
            if memory_device.type != "cuda":
                raise ValueError("Training GPU memory profiling requires a CUDA model.")
        self.train()
        self.optimizer.zero_grad(set_to_none=True)
        data_record_l = DataRecordList(len(self.database_train))
        pending_records = deque()

        batches = iter(self.database_train.data_gpu)
        for step in range(len(self.database_train.data_gpu)):
            with _training_stage(f"train-fetch:{step}"):
                batch = next(batches)
            if self.zmp_ov_cache is not None:
                if batch["name"] != self.zmp_ov_cache.name:
                    raise ValueError(
                        "--zmp_ov_loss batch does not match the resident "
                        "single-system constraint cache."
                    )
                batch = dict(batch)
                batch["input"] = self.zmp_ov_cache.input.detach()
                batch["weight"] = self.zmp_ov_cache.weights
            if profile_memory:
                torch.cuda.synchronize(memory_device)
                torch.cuda.reset_peak_memory_stats(memory_device)
                start_allocated = torch.cuda.memory_allocated(memory_device)
            batch = self.database_train.process_batch(batch, device=self.local_rank)
            tot_loss, data_record, event = self.loss(batch, if_grad=if_grad)
            with _training_stage("backward", batch):
                tot_loss.backward()
            if self.zmp_ov_cache is not None:
                with _training_stage("zmp-ov", batch):
                    zmp_ov_loss = self._zmp_ov_loss(
                        accumulate_parameter_gradients=True
                    )
                zmp_ov_value = zmp_ov_loss.cpu().numpy()
                data_record["loss_zmp_ov"] = zmp_ov_value
                data_record["loss_tot"] = (
                    data_record["loss_tot"] + zmp_ov_value
                )
            with _training_stage("optimizer", batch):
                torch.nn.utils.clip_grad_norm_(self.model.parameters(), self.args.max_norm)
                self.optimizer.step()
                self.scheduler.step()
                self.optimizer.zero_grad(set_to_none=True)
            if profile_memory:
                torch.cuda.synchronize(memory_device)
                peak_allocated = torch.cuda.max_memory_allocated(memory_device)
                peak_reserved = torch.cuda.max_memory_reserved(memory_device)
                jacobian = batch["grad2force"]
                jacobian_bytes = jacobian.numel() * jacobian.element_size()
                force_loss = bool(
                    self.args.if_grad and if_grad and batch["grad_cc_train"].ndim != 0
                )
                mib = 1024**2
                print(
                    f"[train-memory] device={memory_device} step={step} "
                    f"name={batch['name']} force_loss={force_loss} "
                    f"start_allocated_MiB={start_allocated / mib:.3f} "
                    f"peak_allocated_MiB={peak_allocated / mib:.3f} "
                    f"peak_reserved_MiB={peak_reserved / mib:.3f} "
                    f"grad2force_MiB={jacobian_bytes / mib:.3f}",
                    flush=True,
                )
            if event is None:
                data_record_l.add_data_record(data_record)
                continue

            pending_records.append((event, data_record))
            while pending_records and pending_records[0][0].query():
                _, ready_record = pending_records.popleft()
                data_record_l.add_data_record(ready_record)

        while pending_records:
            event, ready_record = pending_records.popleft()
            event.synchronize()
            data_record_l.add_data_record(ready_record)
        data_record_l.trim()
        data_record_l.merge()
        return data_record_l

    @torch.inference_mode()
    def eval_model(self):
        self.eval()
        self.optimizer.zero_grad(set_to_none=True)
        data_record_l = DataRecordList(len(self.database_eval))
        pending_records = deque()

        batches = iter(self.database_eval.data_gpu)
        for step in range(len(self.database_eval.data_gpu)):
            with _training_stage(f"eval-fetch:{step}"):
                batch = next(batches)
            batch = self.database_eval.process_batch(batch, device=self.local_rank)
            _, data_record, event = self.loss(batch, if_train=False)
            if self.zmp_ov_cache is not None and batch["name"] == self.zmp_ov_cache.name:
                zmp_ov_loss = self._zmp_ov_loss_for_eval()
                data_record["loss_zmp_ov"] = zmp_ov_loss.cpu().numpy()
            if event is None:
                data_record_l.add_data_record(data_record)
                continue

            pending_records.append((event, data_record))
            while pending_records and pending_records[0][0].query():
                _, ready_record = pending_records.popleft()
                data_record_l.add_data_record(ready_record)

        while pending_records:
            event, ready_record = pending_records.popleft()
            event.synchronize()
            data_record_l.add_data_record(ready_record)
        data_record_l.trim()
        data_record_l.merge()
        return data_record_l

    @staticmethod
    def b3lyp_weights(like):
        if torch.is_tensor(like):
            return like.new_tensor(B3LYP_WEIGHTS)
        return np.asarray(B3LYP_WEIGHTS, dtype=like.dtype)

    def get_b3lyp_ene(self, rho_cube):
        if self.cube_type == "center_4":
            rho = rho_cube[:, :4]
        elif self.cube_type == "neighbors":
            rho = rho_cube[:, :4, 0]
        elif self.cube_type in ("cube", "cube5"):
            rho = rho_cube[:, :4, self.model.cube_middle]
        else:
            raise ValueError(f"Unknown cube type: {self.cube_type}")
        return (rho * self.b3lyp_weights(rho)).sum(-1)

    def eval_xc_eff(
        self, rho_cube, weights_, weight_response=False, *, return_tensors=False,
        relative_positions=None, neighbor_indices=None, position_response=False,
    ):
        """Optionally return weight derivatives and detached on-device tensors."""
        if self.cube_type == "neighbors" and relative_positions is None:
            raise ValueError("Neighbor XC evaluation requires relative_positions.")
        if neighbor_indices is not None and self.cube_type != "neighbors":
            raise ValueError("Neighbor indices require a neighbors model.")
        if position_response and (relative_positions is None or not weight_response):
            raise ValueError("Position response requires positions and weight_response=True.")
        input_mat = torch.as_tensor(rho_cube, dtype=self.dtype, device=self.device)
        weights_mat = torch.as_tensor(
            weights_.reshape((-1, 1)), dtype=self.dtype, device=self.device
        )
        input_mat.requires_grad = True
        density_input = input_mat
        weights_mat.requires_grad = weight_response
        if relative_positions is not None:
            relative_positions = torch.as_tensor(
                relative_positions, dtype=self.dtype, device=self.device
            )
            if position_response:
                relative_positions.requires_grad_(True)
            if neighbor_indices is not None:
                neighbor_indices = torch.as_tensor(
                    neighbor_indices, dtype=torch.int64, device=self.device
                )
            input_mat, exc_cube = self.model_output(
                input_mat, weights_mat, relative_positions,
                neighbor_indices=neighbor_indices,
            )
        else:
            input_mat, exc_cube = self.model_output(input_mat, weights_mat)
        if neighbor_indices is None:
            baseline_input = density_input if self.cube_type == "neighbors" else input_mat
            baseline = self.get_b3lyp_ene(baseline_input)
        else:
            centers = density_input[neighbor_indices[:, 0], :4]
            baseline = (centers * self.b3lyp_weights(centers)).sum(-1)
        exc_cube += torch.einsum("i,ij->ij", baseline, weights_mat)
        if position_response:
            middle_cube, weight_derivative, edge_derivative = torch.autograd.grad(
                exc_cube.sum(), (density_input, weights_mat, relative_positions),
                materialize_grads=True,
            )
        elif weight_response:
            middle_cube, weight_derivative = torch.autograd.grad(
                torch.sum(exc_cube), (density_input, weights_mat)
            )
        else:
            derivative_input = density_input if self.cube_type == "neighbors" else input_mat
            middle_cube = torch.autograd.grad(torch.sum(exc_cube), derivative_input)[0]
            weight_derivative = None
        outputs = (exc_cube.detach().squeeze(-1), middle_cube.detach())
        if weight_response:
            outputs += (weight_derivative.detach().reshape(-1),)
        if position_response:
            outputs += (edge_derivative.detach(),)
        if return_tensors:
            return outputs
        return tuple(output.cpu().numpy() for output in outputs)
