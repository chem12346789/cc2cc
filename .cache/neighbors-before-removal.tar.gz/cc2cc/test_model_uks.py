"""Test the model. Unrestricted Khon-Sham (with spin)."""

import timeit
import numpy as np
import dftd3.pyscf as disp
import torch

try:
    import cupy as cp
except Exception:  # pragma: no cover
    cp = None

import pyscf
import pyscf.dft

import cc2cc.utils as utils
from cc2cc.utils.run_helpers import load_post_scf_density, load_post_scf_vv10

pyscf.lib.logger.TIMER_LEVEL = 4
VERBOSE = 4


def test_model_uks(
    mol,
    name,
    modeldict,
    data_record,
    args,
):
    """
    Test the model. Unrestricted Khon-Sham (with spin).
    """
    # 2.0 Prepare
    time_ai_start = timeit.default_timer()
    test_mode = getattr(args, "test_mode", "scf")
    post_scf = test_mode != "scf"
    if post_scf and args.if_grad:
        raise ValueError("Post-SCF density modes do not support nuclear gradients.")
    if torch.cuda.is_available() and not args.if_grad and not args.cpu:
        print("Use GPU for DFT calculation.")
        use_gpu = True
        mdft = pyscf.dft.UKS(mol).to_gpu().density_fit()
        Grid = utils.GridGPU
        if modeldict.cube_type == "neighbors":
            from cc2cc.utils.modelscf_uks_no_cube_gpu import get_veff_modified_uks_gpu

            get_veff_modified_uks_gpu(mdft, modeldict, args.max_memory_gpu)
        else:
            utils.get_veff_modified_uks_gpu(mdft, modeldict, args.max_memory_gpu)
    else:
        print("Use CPU for DFT calculation.")
        use_gpu = False
        mdft = pyscf.dft.UKS(mol).density_fit()
        Grid = utils.GridCPU
        if modeldict.cube_type == "neighbors":
            from cc2cc.utils.modelscf_uks_no_cube import get_veff_modified_uks

            get_veff_modified_uks(mdft, modeldict)
        else:
            from cc2cc.utils.modelscf_uks import get_veff_modified_uks

            get_veff_modified_uks(mdft, modeldict)

    if args.baseline == "b3lyp-vv10" or test_mode in (
        "post-b3lyp-nl",
        "post-b3lyp-vv10",
    ):
        mdft.xc = "b3lyp"
        mdft.nlc = "vv10"
    else:
        mdft.xc = "b3lyp"
    mdft.grids = Grid(
        mol,
        args.grid_level,
        input_level=modeldict.input_level,
        cube_type=modeldict.cube_type,
        cube_size=modeldict.cube_size,
    )
    mol.stdout = mdft.stdout

    mdft.verbose = VERBOSE
    mdft.mol.verbose = VERBOSE
    mdft.conv_tol = args.conv_tol
    mdft.conv_tol_grad = args.conv_tol_grad

    if post_scf:
        dm1_scf = load_post_scf_density(
            mol, name, test_mode, grid_level=args.grid_level, use_gpu=use_gpu,
        )
        if use_gpu:
            dm1_scf = cp.asarray(dm1_scf)
        if test_mode == "post-b3lyp-nl":
            mdft.initialize_grids(mol, dm1_scf)
            enlc = load_post_scf_vv10(mdft, name, dm1_scf)
            mdft.nlc = ""
            e_scf = mdft.energy_tot(dm=dm1_scf) + enlc
        else:
            e_scf = mdft.energy_tot(dm=dm1_scf)
    else:
        if args.max_cycle == -1:
            mdft.max_cycle = -1
            if_retry = False
            test_data = utils.TestDataDFT(mol, name, xc_code=mdft.xc, disp=None)
            mdft.kernel(dm0=test_data.dm1_dft)
        else:
            mdft.max_cycle = args.max_cycle
            if_retry = True
            mdft.kernel()

        for factor in [1.0]:
            if mdft.converged is False and if_retry:
                print(f"UKS not converged. Add dynamic level shift with factor {factor}.")
                mdft.level_shift = factor
                mdft.max_cycle = args.max_cycle * 5
                mdft.kernel()
        if mdft.converged is False:
            if args.require_convergence:
                raise RuntimeError(f"UKS did not converge for {name}")
            print("Error: UKS not converged!!! Just use the unconvergence output.")

        dm1_scf = mdft.make_rdm1()
        e_scf = mdft.e_tot

    if (
        args.s6 is None
        or args.s8 is None
        or args.s9 is None
        or args.a1 is None
        or args.a2 is None
        or args.alp is None
    ):
        d3 = disp.DFTD3Dispersion(
            mol, xc="b3lyp" if test_mode == "post-b3lyp-d3" else "hf",
        )
    else:
        param = {
            "s6": args.s6,
            "s8": args.s8,
            "s9": args.s9,
            "a1": args.a1,
            "a2": args.a2,
            "alp": args.alp,
        }
        d3 = disp.DFTD3Dispersion(mol, param=param)
    d3_energy_force = d3.kernel()

    if args.if_grad and args.max_cycle != -1:
        g = mdft.Gradients()
        g.grid_response = bool(args.grid_response)
        g.xc = "b3lyp"
        g.grids = mdft.grids
        if torch.cuda.is_available() and not args.if_grad:
            utils.get_veff_grad_modified_uks_gpu(g, modeldict)
        elif modeldict.cube_type == "neighbors":
            from cc2cc.utils.modelscf_uks_no_cube import get_veff_grad_modified_uks

            get_veff_grad_modified_uks(g, modeldict)
        else:
            utils.get_veff_grad_modified_uks(g, modeldict)
        grad_mdft = g.kernel()
        print(f"Net force check: {np.sum(grad_mdft, axis=0)}")
    else:
        grad_mdft = None

    time_ai = timeit.default_timer() - time_ai_start

    # 3.0 Collect data

    if use_gpu:
        dm1_scf = cp.asnumpy(dm1_scf)

    scf_dipole = pyscf.scf.hf.dip_moment(mol=mol, dm=dm1_scf, unit="A.U.")

    dict_ = {
        "name": name,
        "time_ai": time_ai,
        "scf_ene": e_scf,
        "scf_d3bj_ene": e_scf + d3_energy_force[0],
        "scf_dipole_x": scf_dipole[0],
        "scf_dipole_y": scf_dipole[1],
        "scf_dipole_z": scf_dipole[2],
        "converged": None if post_scf else mdft.converged,
        "test_mode": test_mode,
    }

    if args.if_grad:
        if grad_mdft is not None:
            dict_.update({"scf_grad": grad_mdft})
            dict_.update({"scf_d3bj_grad": grad_mdft + d3_energy_force[1]})
        else:
            dict_.update({"scf_grad": 0})

    if (utils.DATA_PATH / f"data_{name}.npz").exists():
        data = np.load(utils.DATA_PATH / f"data_{name}.npz", allow_pickle=True)
        print(data["mol"])
        print(mol.tostring(format="xyz"))
        print(
            f"energy (ai vs dft) {(e_scf - data['e_dft']) * utils.AU2KCALMOL} Kcal/mol"
        )
        print(f"energy (ai vs cc) {(e_scf - data['e_cc']) * utils.AU2KCALMOL} Kcal/mol")

        dm1_dft = data["dm1_dft"]
        dm1_cc = data["dm1_cc"]
        dm1_ai = dm1_scf
        print(
            f"electronic density (ai vs dft) {utils.diff_rho(mol, dm1_dft, dm1_ai, mdft.grids)}"
        )
        print(
            f"electronic density (ai vs cc) {utils.diff_rho(mol, dm1_cc, dm1_ai, mdft.grids)}"
        )
        print(
            f"electronic density (dft vs cc) {utils.diff_rho(mol, dm1_cc, dm1_dft, mdft.grids)}"
        )
        dipole_dft = pyscf.scf.hf.dip_moment(mol=mol, dm=dm1_dft, unit="A.U.")
        dipole_cc = pyscf.scf.hf.dip_moment(mol=mol, dm=dm1_cc, unit="A.U.")

        print(f"dipole (ai vs dft) {np.linalg.norm(scf_dipole - dipole_dft)}")
        print(f"dipole (ai vs cc) {np.linalg.norm(scf_dipole - dipole_cc)}")
        print(f"dipole (dft vs cc) {np.linalg.norm(dipole_dft - dipole_cc)}")
        grad_dft = data["grad_dft"]
        grad_cc = data["grad_cc"]
        if args.if_grad:
            print(f"gradient (ai vs dft) {np.linalg.norm(grad_mdft - grad_dft)}")
            print(f"gradient (ai vs cc) {np.linalg.norm(grad_mdft - grad_cc)}")
            print(f"gradient (dft vs cc) {np.linalg.norm(grad_dft - grad_cc)}")

    data_record.add_data(dict_)
    data_record.save_csv()
